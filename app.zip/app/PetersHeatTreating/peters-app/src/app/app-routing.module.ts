import { NgModule } from '@angular/core';
import { LoginComponent } from './components/login/login.component';
import {TrackingComponent} from './components/tracking/tracking.component';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './components/user/user.component';
import { AuthGuard } from './service/guards/authguard';
import { NotAuthorizedComponent } from './components/not-authorized/not-authorized.component';
import { RequestAccessComponent } from './components/request-access/request-access.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { ApiTestComponent } from './components/api-test/api-test.component';
import { AccountSettingsComponent } from './components/self-service/account-settings/account-settings.component';
import { ChangeLogTableComponent } from './components/change-log-table/change-log-table.component';
import { ResetPasswordPlusComponent } from './components/reset-password-plus/reset-password-plus.component';
import { AdminAuthGuard } from './service/guards/adminAuthGuard';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'tracking', component: TrackingComponent, canActivate: [AuthGuard]},
  { path: 'users', component: UserComponent, canActivate: [AuthGuard && AdminAuthGuard] },
  { path: 'request-access', component: RequestAccessComponent},

  { path: 'notAuthorized', component: NotAuthorizedComponent},
  { path: 'notauthorized', component: NotAuthorizedComponent},

  { path: 'forgotpassword', component: ForgotPasswordComponent},
  { path: 'forgot-password', component: ForgotPasswordComponent},

  
  { path: 'forgotpassword/:email', component: ForgotPasswordComponent},
  { path: 'forgot-password/:email', component: ForgotPasswordComponent},

  { path: 'resetpassword/:token', component: ResetPasswordComponent},
  { path: 'resetPassword/:token', component: ResetPasswordComponent},
  { path: 'reset-password/:token', component: ResetPasswordComponent},
  { path: 'resetpassword/:token/:email', component: ResetPasswordComponent},
  { path: 'resetPassword/:token/:email', component: ResetPasswordComponent},
  { path: 'reset-password/:token/:email', component: ResetPasswordComponent},

  { path: 'accountsetup/:token/:email', component: ResetPasswordPlusComponent},
  { path: 'account-setup/:token/:email', component: ResetPasswordPlusComponent},
  { path: 'accountSetup/:token/:email', component: ResetPasswordPlusComponent},

  { path: 'not-authorized', component: NotAuthorizedComponent},
  { path: 'api-test', component: ApiTestComponent},
  { path: 'changes', component: ChangeLogTableComponent, canActivate: [AuthGuard && AdminAuthGuard]},

  {path:'myaccount', component: AccountSettingsComponent, canActivate: [AuthGuard]},
  {path:'my-account', component: AccountSettingsComponent, canActivate: [AuthGuard]},


  { path: '**', component: LoginComponent},


];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
