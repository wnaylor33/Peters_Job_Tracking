import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { TokenService } from './service/token.service';
import { MatSidenav } from '@angular/material/sidenav';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'peters-app';
  @ViewChild('sidenav') sidenav: MatSidenav;

  constructor(private tokenService: TokenService, private router: Router){}

  isLoggedIn(){
    return this.tokenService.isLoggedIn();
  }
  logout(){
    this.tokenService.logOut();
    this.router.navigate(['login']);
  }
  navigate(route:string){
    this.router.navigate([route]);
  }
  isAdmin() {
    return this.tokenService.isAdmin();
  }
  closeSidenav(): void {
    this.sidenav.close();
  }
  navigateExternalHomepage(){
    window.open("https://www.petersheattreat.com", "_blank");
  }
}
