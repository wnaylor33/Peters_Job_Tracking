import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { TrackingComponent } from './components/tracking/tracking.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MyMaterialModule } from './material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from './service/auth.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { UserComponent } from './components/user/user.component';
import { EditUserModalComponent } from './components/user/modal/edit-user-modal/edit-user-modal.component';
import { InviteUserModalComponent } from './components/user/modal/invite-user-modal/invite-user-modal.component';
import { NotAuthorizedComponent } from './components/not-authorized/not-authorized.component';
import { UserService } from './service/userService';
import { JWT_OPTIONS } from '@auth0/angular-jwt';
import { AuthInterceptor } from './service/authinterceptor.service';
import { AddHeaderInterceptor } from './service/interceptor/AddHeaderInterceptor';
import { RequestAccessComponent } from './components/request-access/request-access.component';
import { ConfirmModalComponent } from './components/shared/confirm-modal/confirm-modal.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { ApiTestComponent } from './components/api-test/api-test.component';
import { ApiService } from './service/api/api.service';
import { RegisterComponent } from './components/register/register.component';
import { JobService } from './service/jobs.service';
import { CompanyService } from './service/company.service';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccountSettingsComponent } from './components/self-service/account-settings/account-settings.component';
import { LoadingComponent } from './components/shared/loading/loading.component';
import { UserTableComponent } from './components/user/user-table/user-table.component';
import { RequestTableComponent } from './components/user/request-table/request-table.component';
import { TableSortingExampleComponent } from './components/user/table-sorting-example/table-sorting-example.component';
import { ApproveRequestModalComponent } from './components/user/request-table/approve-request-modal/approve-request-modal.component';
import { CombinedAccountsTableComponent } from './components/user/combined-accounts-table/combined-accounts-table.component';
import { ChangeLogTableComponent } from './components/change-log-table/change-log-table.component';
import { AccountChangesService } from './components/change-log-table/changes.services';
import { EstDateFormatPipe } from './components/shared/pipes/est-datepipe';
import { AdminSetPasswordComponent } from './components/user/modal/admin-set-password/admin-set-password.component';
import { RequestService } from './service/request.service';
import { ResetPasswordPlusComponent } from './components/reset-password-plus/reset-password-plus.component';
import { AppBannerComponent } from './components/shared/app-banner/app-banner.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TrackingComponent,
    UserComponent,
    EditUserModalComponent,
    InviteUserModalComponent,
    NotAuthorizedComponent,
    RequestAccessComponent,
    ConfirmModalComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    ApiTestComponent,
    RegisterComponent,
    AccountSettingsComponent,
    LoadingComponent,
    UserTableComponent,
    RequestTableComponent,
    TableSortingExampleComponent,
    ApproveRequestModalComponent,
    CombinedAccountsTableComponent,
    ChangeLogTableComponent,
    EstDateFormatPipe,
    AdminSetPasswordComponent,
    ResetPasswordPlusComponent,
    AppBannerComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MyMaterialModule,
    ReactiveFormsModule,
    FormsModule,
    FlexLayoutModule,
    DragDropModule,
  ],
  providers: [AuthService, UserService, ApiService,JobService,CompanyService,AccountChangesService,RequestService,
  
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AddHeaderInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
    { provide: JWT_OPTIONS, useValue: JWT_OPTIONS },],

  
  bootstrap: [AppComponent]
})
export class AppModule { }
