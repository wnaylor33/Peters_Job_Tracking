import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../service/api/api.service';

@Component({
  selector: 'app-api-test',
  templateUrl: './api-test.component.html',
  styleUrls: ['./api-test.component.scss']
})
export class ApiTestComponent implements OnInit {
  status1 = '';
  status2 = '';
  status3 = '';


  constructor(private apiService: ApiService) { }

  async ngOnInit(): Promise<any> {
    await this.pingServer();
    await this.pingServer2();
    await this.pingServer3();

  }
  async pingServer2() {
    this.status2 = 'Pinging';
    await this.apiService.ping2().subscribe((response) => {
      this.status2 = 'success';
  },
  (error: HttpErrorResponse) => {
    this.status2 = 'failure';  
  });
  }
  async pingServer3() {
    this.status3 = 'Pinging';
    await this.apiService.ping3().subscribe((response) => {
      this.status3 = 'success';
  },
  (error: HttpErrorResponse) => {
    this.status3 = 'failure';  
  });
  }
  async pingServer() {
    this.status1 = 'Pinging';
    await this.apiService.ping().subscribe((response) => {
      this.status1 = 'success';
  },
  (error: HttpErrorResponse) => {
    this.status1 = 'failure';  
  });
  }
}
