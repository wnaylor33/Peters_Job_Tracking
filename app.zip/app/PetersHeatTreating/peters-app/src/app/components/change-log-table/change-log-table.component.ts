import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { AccountChangesService } from './changes.services';

@Component({
  selector: 'app-change-log-table',
  templateUrl: './change-log-table.component.html',
  styleUrls: ['./change-log-table.component.scss']
})
export class ChangeLogTableComponent implements OnInit {
  isLoading = false;
  changeColumns: string[] = ['email', 'fullName', 'companyCode', 'fieldName', 'oldValue', 'newValue', 'created'];
  snackbarOptions: {
  duration: 5000
};

startDate: Date;
endDate: Date = new Date();


@ViewChild(MatPaginator) changePaginator: MatPaginator;
@ViewChild(MatSort) changeSort: MatSort;

changesDataSource: MatTableDataSource<any>;
  changes: Array<any> = []
  constructor(private accountService: AccountChangesService,
    private snackBar: MatSnackBar, 
    ) { 
      this.startDate = new Date();
      this.startDate.setDate(this.endDate.getDate() - 7);
    }
  
  ngOnInit(): void {
    this.loadChanges();
  }
  ngAfterViewInit() {
    this.changesDataSource = new MatTableDataSource<any>(this.changes);
    this.changesDataSource.sort = this.changeSort;
    this.changeSort.disableClear = true;
    this.changesDataSource.paginator = this.changePaginator;
  }
  loadChanges() {
    this.isLoading = true;
    this.accountService.getChanges().subscribe(result => {
      result.forEach((change) => {
        this.changes.push(change);
      })
      this.changesDataSource = new MatTableDataSource<any>(this.changes);
      this.changesDataSource.sort = this.changeSort;
      this.changesDataSource.paginator = this.changePaginator;
      this.isLoading = false;
    },  
    (err =>{
      this.snackBar.open('Error', 'Dismiss');
    }));
  }
  downloadFile() {
    this.isLoading = true;
    this.accountService.download(this.startDate , this.endDate)
    .subscribe((response: any) => {
      let fileName = response.headers.get('content-disposition')
      ?.split(';')[1].split('=')[1];
      let blob: Blob = response.body as Blob;
      let a = document.createElement('a');
      a.download = fileName;
      a.href = window.URL.createObjectURL(blob);
      a.click();
      this.isLoading = false;
    },
    error => {
      this.snackBar.open('Error downloading Report','Error');
      this.isLoading = false;
    },)
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.changesDataSource.filter = filterValue.trim().toLowerCase();

    if (this.changesDataSource.paginator) {
      this.changesDataSource.paginator.firstPage();
    }
  }

}
