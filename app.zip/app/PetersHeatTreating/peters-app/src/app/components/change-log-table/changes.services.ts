import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BASE_URL } from '../../constants';
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  @Injectable({
    providedIn: 'root'
  })
  export class AccountChangesService {
    constructor(private http: HttpClient) { }
    getChanges(): Observable<any[]> {
      return this.http.get<any[]>(BASE_URL + '/change', httpOptions);
    }
    download(startDate: Date, endDate: Date): Observable<any> {
      var timeFrameObject = {startDate, endDate};
      return this.http.post(`${BASE_URL}/change/download`, timeFrameObject,  { observe:'response' ,responseType: 'blob'})

    }
  }