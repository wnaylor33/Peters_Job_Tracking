import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../service/auth.service';
import { TokenService } from '../../service/token.service';
import { MatCardModule } from '@angular/material/card';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  form: FormGroup;
  hasError = false;
  isLoading = false;
  hasSuccess = false;
  private returnUrl: string;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private tokenService: TokenService,

    private authService: AuthService
 ) {
  }
  async ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/tracking';
    let email = '';
    if(this.route.snapshot.paramMap.get('email'))  {
      email = String(this.route.snapshot.paramMap.get('email'));
    }
    this.form = this.fb.group({
      username: [email, Validators.required],
    });
    if (await this.tokenService.isLoggedIn()) {
      await this.router.navigate([this.returnUrl]);
    }

  }
  async onSubmit() {
    this.hasSuccess = false;
    if (this.form.valid) {
      try {
        this.isLoading = true;
        const username:String = this.form.get('username').value;
        await this.authService.forgotPassword(username.trim()).subscribe(
          data => {
            this.hasSuccess = true;
            this.isLoading = false;
          },
          err => {
            this.hasError = true;
            this.isLoading = false;
          }
        );
        
      } catch (err) {
      this.hasError = true;
      this.isLoading = false;
      }
    }
  }
}