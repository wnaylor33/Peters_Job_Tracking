import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../service/auth.service';
import { TokenService } from '../../service/token.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  form: FormGroup;
  invalidPassword = false;
  isLoading = false;
  hasError = false;
  private formSubmitAttempt: boolean;
  private returnUrl: string;
  bannerMessage: string;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private tokenService: TokenService,

    private authService: AuthService
 ) {
  }
  async ngOnInit() {
    this.bannerMessage = 'The Job Tracking Portal is currently down for maintenance. We are happy to give you status updates if you call us at 814-333-1782. If you opted in to receive job tracking status emails they are still functioning. We apologize for any inconvenience this has caused.';
    this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/tracking';
    this.form = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
    if (await this.tokenService.isLoggedIn()) {
      await this.router.navigate([this.returnUrl]);
    }
  }
  async onSubmit() {

    this.formSubmitAttempt = false;
    this.invalidPassword = false;

    if (this.form.valid) {
      try {
        this.isLoading = true;
        const username: String = this.form.get('username').value;
        const password: String = this.form.get('password').value;
        await this.authService.login({
          username: username.trim(), password
        }).subscribe(
          data => {
            this.tokenService.saveToken(data.token);
            this.tokenService.saveUser(data);
            this.isLoading = false;
            this.router.navigate(['tracking']);
          },
          err => {
            this.isLoading = false;
            if(err.status === 401){
              this.invalidPassword = true;
            }
            else {
            this.hasError = true;
            }
          }
        );
        
      } catch (err) {
        this.isLoading = false;
        this.hasError= true;
      }
    } else {
      this.formSubmitAttempt = true;
    }
  }
}