import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PASSWORD_REGEX } from '../../constants';
import { AuthService } from '../../service/auth.service';
import { TokenService } from '../../service/token.service';
import { UserService } from '../../service/userService';

@Component({
  selector: 'app-request-access',
  templateUrl: './request-access.component.html',
  styleUrls: ['./request-access.component.scss']
})
export class RequestAccessComponent implements OnInit {
  form: FormGroup;
  public loginInvalid: boolean;
  hasSubmitted = false;
  hasError = false;  
  success = false;
  isLoading = false;
  errorMessage = 'An unexpected error occurred. Try again';

  private formSubmitAttempt: boolean;
  private returnUrl: string;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private tokenService: TokenService,

    private userService: UserService
 ) {
  }
  ngOnInit() {
    this.form = this.fb.group({
      email: ['', Validators.email],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      companyName: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      emailFrequency: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required]
    });
  }
  private initErrorStatus() {
    this.hasError = false;
    this.loginInvalid = false;
    this.formSubmitAttempt = false;
    this.errorMessage = 'An unexpected error occurred. Try again';

  }
  async onSubmit() {
    this.hasSubmitted = true;
    this.initErrorStatus();
    if (this.form.valid) {
      try {
        const email = this.form.get('email')?.value;
        const firstName = this.form.get('firstName')?.value;
        const lastName = this.form.get('lastName')?.value;
        const companyName = this.form.get('companyName')?.value;
        const password = this.form.get('password')?.value;
        const confirmPassword = this.form.get('confirmPassword')?.value;
        const emailFrequency = this.form.get('emailFrequency')?.value;
        const city = this.form.get('city')?.value;
        const state = this.form.get('state')?.value;
        if(password != confirmPassword){
          this.hasError = true;
          this.errorMessage = 'Passwords must match.';
          return;
        }
        if(!this.validateRegex(password)){
          this.hasError = true;
          this.errorMessage = 'Password must be at least eight characters and contain at least one uppercase letter, one lowercase letter, one number, and a special character';
          return;
        }
        this.isLoading = true;
        await this.userService.createRequest({
          email, firstName, lastName, companyName, password, confirmPassword, emailFrequency, city, state
        }).subscribe(
          data => {
            this.success = true;
            this.isLoading = false;
          },
          err => {
            this.hasError = true;
            this.isLoading = false;
            if(err != null && err.error != null && err.error.message != null)
            var alreadyExists = err.error.message.toLowerCase().findIndex('user already exists');
            if(alreadyExists > -1) {
              this.errorMessage = 'An Account already exists for the email address provided.';
            }
          }
        );
        
      } catch (err) {
      this.loginInvalid = true;
      this.isLoading = false;
      }
    } else {
      this.formSubmitAttempt = true;
    }
  }
  validateRegex(value: string) {
    var result = PASSWORD_REGEX.test(value);
    return result;
  }
  navigate(route:string){
    this.router.navigate([route]);
  }
  
}