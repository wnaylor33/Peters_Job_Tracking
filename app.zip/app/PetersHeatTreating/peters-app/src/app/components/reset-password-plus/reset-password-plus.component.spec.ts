import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetPasswordPlusComponent } from './reset-password-plus.component';

describe('ResetPasswordPlusComponent', () => {
  let component: ResetPasswordPlusComponent;
  let fixture: ComponentFixture<ResetPasswordPlusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResetPasswordPlusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetPasswordPlusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
