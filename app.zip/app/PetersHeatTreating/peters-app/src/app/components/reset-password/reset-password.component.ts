import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { PASSWORD_REGEX } from '../../constants';
import { AuthService } from '../../service/auth.service';
import { ErrorCode, RequestService } from '../../service/request.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  isLoading = false;
  email = '';
  form: FormGroup;
  token: string;
  hasError = false;
  hasRegexError = false;
  passwordsMatch = true;
  passwordDisabled = false;
  isSuccess = false;
  errorMessage = 'An unexpected error occured. Please try again.'
  errorType: ErrorCode | null = null;
  public get ErrorEnum() {
    return ErrorCode; 
  }

  constructor(private route: ActivatedRoute, private fb: FormBuilder,
    private authService: AuthService,
    private requestService: RequestService
    ) {}
  ngOnInit(): void {
    this.token = String(this.route.snapshot.paramMap.get('token'));
    this.email = '';
    if(this.route.snapshot.paramMap.get('email'))  {
      this.email = String(this.route.snapshot.paramMap.get('email'));
      this.passwordDisabled = true;
    }
    this.form = this.fb.group({
      username: [
        {value: this.email , disabled: this.passwordDisabled}, 
        [Validators.required, Validators.email]
      ],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
    });
    
  }
  onSubmit(): void {
    if (this.form.valid) {
    this.errorMessage = 'An unexpected error occured. Please try again.'
    this.errorType = null;
    this.hasError = false;
    this.hasRegexError = false;
    this.passwordsMatch = true;
    const password = this.form.get('password').value;
        const confirmPassword = this.form.get('confirmPassword').value;
        const username = this.form.get('username').value;
        if(password !== confirmPassword) {
          this.passwordsMatch = false;
          return;
        }
        
        this.hasRegexError = this.validateRegex(password);

        if(this.hasRegexError){
          return;
        }
        this.isLoading = false;
    this.authService.resetPassword(
      {
        username,
        password,
        confirmPassword,
        token: this.token
      }
    ).subscribe(
      () => {
        this.isSuccess = true;
        this.hasError = false;
        this.isLoading = false;
      },
      err => {
        this.isLoading = false;
        this.hasError = true;
        this.isSuccess = false;
        this.errorType = this.requestService.ProcessError(err);
        if(this.errorType === ErrorCode.InvalidToken) {
          this.errorMessage = 'The link used to reset your password has expired. Click the button below to request a new one.';
        }
      }
    );
    }
  }
  validateRegex(value: string) {
    var result = PASSWORD_REGEX.test(value);
    return !result;
  }
}

export class PasswordResetModel{
  username: string;
  password: string;
  confirmPassword: string;
  token: string;

  constructor() {
    this.username = '';
    this.password = '';
    this.confirmPassword = '';
    this.token = '';
  }
}