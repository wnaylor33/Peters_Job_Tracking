import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserService } from '../../../service/userService';

@Component({
  selector: 'app-account-settings',
  templateUrl: './account-settings.component.html',
  styleUrls: ['./account-settings.component.scss']
})
export class AccountSettingsComponent implements OnInit {
  user: any = {};
  isLoading = false;
  hasSubmitted = false;

  constructor(private userService: UserService,
    private snackBar: MatSnackBar, 
    ) { }

  ngOnInit(): void {
    this.getUser();
  }
  getUser() {
    this.userService.getCurrentUserAccount().subscribe(result=> {
      this.user = result;
    },
    (error:any) => {
      this.snackBar.open('An Error Occurred', 'Dismiss');
    });
  }
  updateUser() {
    this.hasSubmitted = true;
    try{
      this.isLoading = true;
    this.userService.userUpdateUser(this.user).subscribe(async result => {
      this.snackBar.open('Success', 'Dismiss');
      this.isLoading = false;
    },
    (err:any) =>{
      this.snackBar.open('Error', 'Dismiss');
      this.isLoading = false;

    });
  }
  catch(err:any) {
    this.isLoading = false;
  }
  }

}
