import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
    name: 'estDateFormatPipe',
})
export class EstDateFormatPipe implements PipeTransform {
    transform(value: string) {
       var datePipe = new DatePipe("en-US");
       var date = new Date(value);
       date.setHours(date.getHours() - 5);

        var piped = datePipe.transform(date, 'shortTime');
        
        return piped;
    }
}