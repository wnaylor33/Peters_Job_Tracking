import { Component, AfterViewInit, ViewChild, OnInit } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { CompanyService } from '../../service/company.service';
import { JobService } from '../../service/jobs.service';
import { forkJoin } from 'rxjs';
import { TokenService } from '../../service/token.service';
import { CONTACT_EMAIL, CONTACT_PHONE } from '../../constants';


@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.scss']
})
export class TrackingComponent implements AfterViewInit, OnInit {
  isLoadingJobs = false;
  isLoadingCompanies = false;
  email = CONTACT_EMAIL;
  phoneNumber = CONTACT_PHONE;

  jobs: Array<any> = [];
  companies: Array<any> = [];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) jobSort: MatSort;


  dataSource = new MatTableDataSource<any>(this.jobs);

  ngAfterViewInit() {
    if(!this.isRegistered()) {
      return;
    }
    this.dataSource = new MatTableDataSource(this.jobs);
    this.dataSource.sort = this.jobSort;
    this.jobSort.disableClear = true;

    this.dataSource.paginator = this.paginator;
    this.dataSource.paginator.firstPage();
  }
  displayedColumns: string[] = ['jobReceived', 'jobNumber', "custCode", 'customerPo', 'materialCode', 'status', 'statusTime', 'shipping', 'trackingNumber'];


  
async getJobs() {
  if(!this.isRegistered()) {
    return;
  }
  this.jobs = [];
  try {
  this.isLoadingJobs = true;
  await this.jobService.getJobs().subscribe(result => {
    result.forEach(job => {
      this.jobs.push(job);
    })
    this.dataSource = new MatTableDataSource<any>(this.jobs);
    this.dataSource.sort = this.jobSort;

    this.dataSource.paginator = this.paginator;
    this.isLoadingJobs = false;

  },
  (err: any)=> {  this.isLoadingJobs = false;  },
  ()=> {});
  }
  catch(ex:any) {
    this.isLoadingJobs = false;
  }
}
async getCompanies() {
  this.companies = [];
  this.isLoadingCompanies = true;

  await this.companyService.getCompanies().subscribe(result => {
    result.forEach(company => {
      this.companies.push(company);
    })
    this.isLoadingCompanies = false;
  }),
    err => {
      this.isLoadingCompanies = false;
    }
}
  constructor(private jobService: JobService
    , private companyService: CompanyService
    , private tokenService: TokenService
    ) { }
  ngOnInit() {
    this.dataSource.sortingDataAccessor = (data: any, sortHeaderId: string): string => {
      if (typeof data[sortHeaderId] === 'string') {
        return data[sortHeaderId].toLocaleLowerCase();
      }
    
      return data[sortHeaderId];
    }  
    this.loadData();

  }

  isRegistered(): boolean {
    return this.tokenService.isRegistered();
  }
  
  loadData() {
    if(!this.isRegistered()) {
      return;
    }
    this.isLoadingCompanies = true;
    this.isLoadingJobs = true;
    this.companies = [];
    this.jobs = [];
    forkJoin([
      this.companyService.getCompanies(),
      this.jobService.getJobs()]
    ).subscribe(([companies, jobs]) => {
      companies.forEach(company => {
        this.companies.push(company);
      });

      jobs.forEach((job) => {
        try{
          if(job.custCode !== null && job.custCode !== ''){
        const index = companies.findIndex(t=> t.id === job.custCode);
        if(index > 0) {
            const myCompany = this.companies[index];
            job.custCode = `${myCompany.name} - ${myCompany.id}`;
        }
      }
      }
      catch(e:any){
      }
      this.jobs.push(job);
      });

    this.isLoadingCompanies = false;
    this.isLoadingJobs = false;

    
    this.dataSource = new MatTableDataSource<any>(this.jobs);
    this.dataSource.sort = this.jobSort;
    this.dataSource.paginator = this.paginator;
    },
    (err) =>{
    this.isLoadingCompanies = false;
    this.isLoadingJobs = false;
    })
      
  }


  

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}
