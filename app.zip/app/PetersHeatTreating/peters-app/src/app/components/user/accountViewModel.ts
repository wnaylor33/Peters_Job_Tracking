import { IAccountRequest } from "../../domain/IAccountRequest";
import { IMyUser } from "../../domain/IMyUser";

export class AccountViewModel {
    id: string;
    firstName :string;
    lastName: string;
    companyName: string;
    companyCode: string;
    email: string;
    enabled: boolean;
    enabledLabel: string = '';
    lastLogin: Date | null = null;
    isAdmin = false;
    isAdminLabel = '';
    objectType: 'Account' | 'Request';
    isRequest: boolean;
    parent: IMyUser | IAccountRequest;
    constructor() {
  
    }
    buildFromRequest(entity: IAccountRequest) {
      this.id = entity.id.toString();
      this.firstName = entity.firstName;
      this.lastName = entity.lastName;
      this.email = entity.email;
      this.enabled = true;
      this.companyName = entity.companyName;
      this.isRequest = true;
      this.parent = entity;
      this.objectType = 'Request';
    }
    buildFromUser(entity: IMyUser, companies: Array<any>) {
      this.id = entity.id;
      this.firstName = entity.firstName;
      this.lastName = entity.lastName;
      this.email = entity.email;
      if(entity.lockoutEnabled) {
        this.enabled = false
        this.enabledLabel = 'No';
      } else {
        this.enabled = true;
        this.enabledLabel = 'Yes';
      }
      if(entity.lastLogin != null) {
        this.lastLogin = entity.lastLogin;
      }
      
      this.companyCode = entity.companyCode;
      if(entity.companyCode != null) {
      this.companyName = this.getCompanyDetails(entity.companyCode, companies);
      } else if(entity.companyName != null) {
        this.companyName = entity.companyName;
      }
      this.isAdminLabel = 'No';
      if(entity.isAdmin) {
        this.companyCode = 'ADMIN';
        this.companyName = 'ADMIN';
        this.isAdminLabel = 'Yes';
      }
      this.isRequest = false;
      this.objectType = 'Account';
      this.parent = entity;
    }
    getCompanyDetails(target: string, companies: Array<any>) {
      if(companies.length < 1) {
        return '';
      }
      const index = companies.findIndex(t=> t.id.toLowerCase().trim() === target.toLocaleLowerCase().trim());
      if(index < 0) {
        return '';
      }
      const myCompany = companies[index];
      return myCompany.name;
    }
  }
  