import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CombinedAccountsTableComponent } from './combined-accounts-table.component';

describe('CombinedAccountsTableComponent', () => {
  let component: CombinedAccountsTableComponent;
  let fixture: ComponentFixture<CombinedAccountsTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CombinedAccountsTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CombinedAccountsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
