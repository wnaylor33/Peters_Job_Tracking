import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { IAccountRequest } from '../../../domain/IAccountRequest';
import { IMyUser } from '../../../domain/IMyUser';
import { AuthService } from '../../../service/auth.service';
import { UserService } from '../../../service/userService';
import { ConfirmModalComponent } from '../../shared/confirm-modal/confirm-modal.component';
import { AccountViewModel } from '../accountViewModel';
import { AdminSetPasswordComponent } from '../modal/admin-set-password/admin-set-password.component';
import { EditUserModalComponent } from '../modal/edit-user-modal/edit-user-modal.component';
import { InviteUserModalComponent } from '../modal/invite-user-modal/invite-user-modal.component';
import { ApproveRequestModalComponent } from '../request-table/approve-request-modal/approve-request-modal.component';

@Component({
  selector: 'app-combined-accounts-table',
  templateUrl: './combined-accounts-table.component.html',
  styleUrls: ['./combined-accounts-table.component.scss']
})
export class CombinedAccountsTableComponent implements OnInit {
  userColumns: string[] = ['email', 'firstName', 'lastName', 'companyCode',  'companyName', 'enabledLabel','isAdminLabel', 'lastLogin', 'actions'];
  snackbarOptions: {
  duration: 5000
  };
  @Input() users: AccountViewModel[];
  @Input() companies: any[];
  @ViewChild(MatPaginator) userPaginator: MatPaginator;
  @ViewChild(MatSort) userSort: MatSort;

userDataSource: MatTableDataSource<AccountViewModel>;


    constructor(public dialog: MatDialog,
      private snackBar: MatSnackBar, 
      private authService: AuthService,
      private userService: UserService) {}
      
      ngOnInit(): void {
      }

      initDataSource(){
        this.userDataSource = new MatTableDataSource<AccountViewModel>(this.users);
        this.userDataSource.sort = this.userSort;
        this.userDataSource.paginator = this.userPaginator;
      }
    ngAfterViewInit() {
      this.userDataSource = new MatTableDataSource<AccountViewModel>(this.users);
        this.userDataSource.sort = this.userSort;
        this.userSort.disableClear = true;

        this.userDataSource.paginator = this.userPaginator;
        this.userDataSource.paginator.firstPage();
    }
    applyFilter(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
      this.userDataSource.filter = filterValue.trim().toLowerCase();
  
      if (this.userDataSource.paginator) {
        this.userDataSource.paginator.firstPage();
      }
    }
    deleteUser(user: any) {
      const dialogRef = this.dialog.open(ConfirmModalComponent, {
        data: {message: `Are you sure you want to Delete User: ${user.email}?`}    });
  
      dialogRef.afterClosed().subscribe(result => {
        if(result) {
          this.userService.deleteUser(user).subscribe(denyResult => {
            var indexToRemove = this.users.findIndex(t=> t.id === user.id);
            this.users.splice(indexToRemove, 1);  
            this.initDataSource();
                    },
          (error) => {
            this.snackBar.open('An Error Occurred','Dismiss');
          });
        }
      });
    }
    adminSetPassword(user: IMyUser){
      const dialogRef = this.dialog.open(AdminSetPasswordComponent, {
        minWidth: '25vw',
        minHeight:"25vh",
        data: user,
      });
      dialogRef.afterClosed().subscribe(dialogResult =>{
        if(!dialogResult){
          return;
        }
        this.userService.adminSetPassword(dialogResult).subscribe((updateResult) => {
          this.snackBar.open('Success', 'Dismiss', this.snackbarOptions);
        },
        (err) => {
          this.snackBar.open('An error occurred', 'Dismiss', this.snackbarOptions);
        });
      });
    }
    sendWelcomeEmail(user:any) {
      this.userService.sendWelcomeEmail(user).subscribe((result) => {
        this.snackBar.open('Success', 'Dismiss', this.snackbarOptions);
      },
      (error) => {
        this.snackBar.open('An error occurred', 'Dismiss', this.snackbarOptions);
      })
    }
    editUserModal(user:any) {
      const originalAdmin = user.isAdmin;
      const dialogRef = this.dialog.open(EditUserModalComponent, {
        minWidth: '50vw',
        minHeight:"50vh",
        data: {user, 
          companies: this.companies
        }
      });
  
      dialogRef.afterClosed().subscribe(result => {
        if(result) {
          if(!originalAdmin && result.isAdmin) {
            const dialogRef = this.dialog.open(ConfirmModalComponent, {
              data: {message: `Are you sure you want to make: ${user.email} an Admin?`}    });
        
            dialogRef.afterClosed().subscribe(confirmed => {
              if(confirmed) {
                this.userService.updateUser(result).subscribe(async result => {
                  result.isAdmin = true;
                  var match = this.users.findIndex(t=> t.id === user.id);
                  var newUser = new AccountViewModel();
                  newUser.buildFromUser(result, this.companies);
                  //this.users.splice(match, 1);   
                  this.users.splice(match, 1);
                  this.users.push(newUser);
                  this.snackBar.open('Success', 'Dismiss', this.snackbarOptions);
                  this.initDataSource();
                },
                err => {
                  this.snackBar.open('An error occurred updating User', 'Dismiss', this.snackbarOptions);
                  });
              }
              else {
                user.isAdmin = false;                
              }
            });
          }
          else{
            this.userService.updateUser(result).subscribe(async result => {
              var match = this.users.findIndex(t=> t.id === user.id);
              var newUser = new AccountViewModel();
              newUser.buildFromUser(result, this.companies);
              // if(user.isAdmin) {
              //   newUser.isAdmin = true;
              //   result.isAdmin = true;
              // }
              this.users.splice(match, 1);
              this.users.push(newUser);
              this.snackBar.open('Success', 'Dismiss', this.snackbarOptions);
              this.initDataSource();
            },
            err => {
              this.snackBar.open('An error occurred updating User', 'Dismiss', this.snackbarOptions);
              });

          }
        }});
          
          
    }
    async sendResetPasswordLink(row: IMyUser) {
      await this.authService.forgotPassword(row.email).subscribe(
        data => {
          this.snackBar.open('Success', 'Dismiss', this.snackbarOptions);
        },
        err => {
          this.snackBar.open('Error', 'Dismiss', this.snackbarOptions);

        }
      );
    }
    public inviteUserModal(): void {
      const dialogRef = this.dialog.open(InviteUserModalComponent, {
        minWidth: '50vw',
        minHeight:"50vh",
        data: {email: 'email', firstName: 'first', lastName:'last'},
      });
  
      dialogRef.afterClosed().subscribe(result => {
        if(result){
          this.authService.register(result).subscribe(result =>{
            
            this.snackBar.open('Success', 'Dismiss', this.snackbarOptions);
          }),
        err => {
          this.snackBar.open('An error occurred creating a new user', 'Dismiss', this.snackbarOptions);
          }
        }
      });
    }
    async denyAccountRequest(request: IAccountRequest){
      const dialogRef = this.dialog.open(ConfirmModalComponent, {
        data: {message: `Are you sure you want to Deny the request for ${request.email}?`}    });
  
      dialogRef.afterClosed().subscribe(result => {
        if(result) {
          this.userService.denyRequest(request).subscribe(denyResult => {
            var indexToRemove = this.users.findIndex(t=> t.id === request.id.toString());
            this.users.splice(indexToRemove, 1);  
            this.initDataSource();
  
          },
          (error) => {
            this.snackBar.open('An Error Occurred','Dismiss');
          });
        }
      });
    }
    
    async approveAccountRequest(request: IAccountRequest){
      const dialogRef = this.dialog.open(ApproveRequestModalComponent, {
        minWidth: '30vw',
        data: {
              companies: this.companies,
              request
            }    
          });
  
      dialogRef.afterClosed().subscribe(result => {
        if(result) {
          this.userService.approveRequest(result).subscribe(approveResult => {
            //TO DO: fire event alerting of new user to add to users
            var indexToRemove = this.users.findIndex(t=> t.id === request.id.toString());
            this.users.splice(indexToRemove, 1);   
            this.snackBar.open('Success','Dismiss');
            this.initDataSource();
          },
          (err)=>{
            this.snackBar.open('An Error Occurred','Dismiss');
  
          });
        }
      });
    }
}
