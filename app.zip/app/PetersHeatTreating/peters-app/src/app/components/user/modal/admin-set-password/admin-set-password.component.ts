import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PASSWORD_REGEX } from '../../../../constants';
import { UserService } from '../../../../service/userService';

@Component({
  selector: 'app-admin-set-password',
  templateUrl: './admin-set-password.component.html',
  styleUrls: ['./admin-set-password.component.scss']
})
export class AdminSetPasswordComponent implements OnInit {

  form: FormGroup;
  token: string;
  hasError = false;
  hasRegexError = false;
  passwordsMatch = true;
  isSuccess = false;
  errorMessage = 'An unexpected error occured. Please try again.'
  
  constructor(private fb: FormBuilder,
  public dialogRef: MatDialogRef<AdminSetPasswordComponent>,
  @Inject(MAT_DIALOG_DATA) public data: any,
  private userService: UserService) {}
  ngOnInit(): void {
    this.form = this.fb.group({
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
    });
  }
  onSubmit(): void {
    this.hasError = false;
    this.hasRegexError = false;
    this.passwordsMatch = true;
    const password = this.form.get('password').value;
        const confirmPassword = this.form.get('confirmPassword').value;
        if(password !== confirmPassword) {
          this.passwordsMatch = false;
          return;
        }
        
        this.hasRegexError = this.validateRegex(password);

        if(this.hasRegexError){
          return;
        }
        return this.dialogRef.close({
          id:this.data.id,
          password,
          confirmPassword
        });
      }
  validateRegex(value: string) {
    var result = PASSWORD_REGEX.test(value);
    return !result;
  }

}
