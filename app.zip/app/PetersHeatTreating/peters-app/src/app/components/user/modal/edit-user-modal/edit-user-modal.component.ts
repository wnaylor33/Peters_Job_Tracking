import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { IContactInfo } from '../../../../domain/IContactInfo';
import { IMyUser } from '../../../../domain/IMyUser';
import { CompanyService } from '../../../../service/company.service';
import { UserService } from '../../../../service/userService';

@Component({
  selector: 'app-edit-user-modal',
  templateUrl: './edit-user-modal.component.html',
  styleUrls: ['./edit-user-modal.component.scss']
})
export class EditUserModalComponent implements OnInit {
  companies: Array<any> = [];
  user: IMyUser;
  isLoading = false;
  contactInfo: IContactInfo;
  constructor(
    private companyService: CompanyService,
    private userService: UserService,
    private snackBar: MatSnackBar, 
    public dialogRef: MatDialogRef<EditUserModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {}
  async ngOnInit() {
    this.companies = this.data.companies;
    this.user = this.data.user;
    await this.getContactInfo();
  }
  getContactInfo() {
    this.isLoading = true;
    this.userService.getContactInfo(this.data.user.email).subscribe((result) => {
      this.contactInfo = result;
      this.user.emailFrequency = result.emailFrequency;
      this.isLoading = false;
    }),
    () => {this.snackBar.open('Error getting Contact Information', 'Dismiss');
      this.isLoading = false;
  }
  }
  onSubmit() {
    this.dialogRef.close(this.user);

  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
