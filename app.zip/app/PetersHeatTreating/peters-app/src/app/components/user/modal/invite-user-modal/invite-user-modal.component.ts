import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CompanyService } from '../../../../service/company.service';
import { EditUserModalComponent } from '../edit-user-modal/edit-user-modal.component';

@Component({
  selector: 'app-invite-user-modal',
  templateUrl: './invite-user-modal.component.html',
  styleUrls: ['./invite-user-modal.component.scss']
})
export class InviteUserModalComponent implements OnInit {
  hasError = false;
  companies: Array<any> = [];
  email = '';
  firstName = '';
  lastName = '';
  companyCode = '';
  constructor(
    private companyService: CompanyService,
    public dialogRef: MatDialogRef<EditUserModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {}
  async ngOnInit(): Promise<void> {
    await this.getCompanies();
  }
  onSubmit() {
    this.dialogRef.close({
      email:this.email, firstName:this.firstName,
      lastName:this.lastName, companyCode:this.companyCode });

  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  async getCompanies() {
    this.companies = [];
    await this.companyService.getCompanies().subscribe(result => {
      result.forEach(company => {
        this.companies.push(company);
      });
  
    });
  }
}
