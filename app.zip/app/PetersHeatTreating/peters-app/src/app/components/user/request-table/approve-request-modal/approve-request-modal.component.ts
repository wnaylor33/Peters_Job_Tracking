import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-approve-request-modal',
  templateUrl: './approve-request-modal.component.html',
  styleUrls: ['./approve-request-modal.component.scss']
})
export class ApproveRequestModalComponent implements OnInit {constructor(
  public dialogRef: MatDialogRef<ApproveRequestModalComponent>,
  @Inject(MAT_DIALOG_DATA) public data: any,
) {}
ngOnInit(): void {
}
}
