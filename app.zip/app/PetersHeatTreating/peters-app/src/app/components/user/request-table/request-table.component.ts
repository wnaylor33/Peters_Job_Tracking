import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { IAccountRequest } from '../../../domain/IAccountRequest';
import { AuthService } from '../../../service/auth.service';
import { UserService } from '../../../service/userService';
import { ConfirmModalComponent } from '../../shared/confirm-modal/confirm-modal.component';
import { ApproveRequestModalComponent } from './approve-request-modal/approve-request-modal.component';

@Component({
  selector: 'app-request-table',
  templateUrl: './request-table.component.html',
  styleUrls: ['./request-table.component.scss']
})
export class RequestTableComponent implements OnInit {

  requestColumns: string[] = ['email', 'firstName', 'lastName', 'companyName', 'companyCode',  'approve', 'deny'];
  snackbarOptions: {
  duration: 5000
};

@Input() requests: IAccountRequest[];
@Input() companies: Array<any>;



@ViewChild(MatPaginator) requestPaginator: MatPaginator;
@ViewChild(MatSort) requestSort: MatSort;

requestDataSource: MatTableDataSource<IAccountRequest>;


    constructor(public dialog: MatDialog,
      private snackBar: MatSnackBar, 
      private userService: UserService) {}

    ngAfterViewInit() {
      this.requestDataSource = new MatTableDataSource<IAccountRequest>(this.requests);
      this.requestDataSource.sort = this.requestSort;
      this.requestDataSource.paginator = this.requestPaginator;
    }
    async denyAccountRequest(request: IAccountRequest){
    const dialogRef = this.dialog.open(ConfirmModalComponent, {
      data: {message: `Are you sure you want to Deny the request for ${request.email}?`}    });

    dialogRef.afterClosed().subscribe(result => {
      if(result) {
        this.userService.denyRequest(request).subscribe(denyResult => {
          var indexToRemove = this.requests.findIndex(t=> t.email === request.email);
          this.requests.splice(indexToRemove, 1);  
          this.requestDataSource = new MatTableDataSource<any>(this.requests);
        },
        (error) => {
          this.snackBar.open('An Error Occurred','Dismiss');
        });
      }
    });
  }
  
  async approveAccountRequest(request: IAccountRequest){
    const dialogRef = this.dialog.open(ApproveRequestModalComponent, {
      minWidth: '30vw',
      data: {
            companies: this.companies,
            request
          }    
        });

    dialogRef.afterClosed().subscribe(result => {
      if(result) {
        this.userService.approveRequest(result).subscribe(approveResult => {
          //TO DO: fire event alerting of new user to add to users
          var indexToRemove = this.requests.findIndex(t=> t.email === result.email);
          this.requests.splice(indexToRemove, 1);   
          this.snackBar.open('Success','Dismiss');
          this.requestDataSource = new MatTableDataSource<any>(this.requests);
        },
        (err)=>{
          this.snackBar.open('An Error Occurred','Dismiss');

        });
      }
    });
  }
    applyFilter(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
      this.requestDataSource.filter = filterValue.trim().toLowerCase();
  
      if (this.requestDataSource.paginator) {
        this.requestDataSource.paginator.firstPage();
      }
    }
ngOnInit(): void {
}

}
