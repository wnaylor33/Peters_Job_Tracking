import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { IMyUser } from '../../../domain/IMyUser';
import { AuthService } from '../../../service/auth.service';
import { UserService } from '../../../service/userService';
import { ConfirmModalComponent } from '../../shared/confirm-modal/confirm-modal.component';
import { EditUserModalComponent } from '../modal/edit-user-modal/edit-user-modal.component';
import { InviteUserModalComponent } from '../modal/invite-user-modal/invite-user-modal.component';

@Component({
  selector: 'app-user-table',
  templateUrl: './user-table.component.html',
  styleUrls: ['./user-table.component.scss']
})
export class UserTableComponent implements OnInit {
  userColumns: string[] = ['email', 'firstName', 'lastName', 'companyCode', 'lockoutEnabled', 'isAdminLabel', 'edit'];
  snackbarOptions: {
  duration: 5000
};

@Input() users: IMyUser[];
@Input() companies: Array<any>;



@ViewChild(MatPaginator) userPaginator: MatPaginator;
@ViewChild(MatSort) userSort: MatSort;

userDataSource: MatTableDataSource<IMyUser>;


    constructor(public dialog: MatDialog,
      private snackBar: MatSnackBar, 
      private authService: AuthService,
      private userService: UserService) {}
      

    ngAfterViewInit() {
      this.userDataSource = new MatTableDataSource<IMyUser>(this.users);
      this.userDataSource.sort = this.userSort;
      this.userDataSource.paginator = this.userPaginator;
      this.userDataSource.paginator.firstPage();
    }
    deleteUser(user: any) {
      const dialogRef = this.dialog.open(ConfirmModalComponent, {
        data: {message: `Are you sure you want to Delete User: ${user.email}?`}    });
  
      dialogRef.afterClosed().subscribe(result => {
        if(result) {
          this.userService.deleteUser(user).subscribe(denyResult => {
            var indexToRemove = this.users.findIndex(t=> t.email === user.email);
            this.users.splice(indexToRemove, 1);  
            this.userDataSource = new MatTableDataSource<any>(this.users);
            this.snackBar.open('Success','Dismiss');

          },
          (error) => {
            this.snackBar.open('An Error Occurred','Dismiss');
          });
        }
      });
    }

    sendWelcomeEmail(user:any) {
      this.userService.sendWelcomeEmail(user).subscribe((result) => {
        this.snackBar.open('Success', 'Dismiss', this.snackbarOptions);
      },
      (error) => {
        this.snackBar.open('An error occurred', 'Dismiss', this.snackbarOptions);
      })
    }
    editUserModal(user:any) {
      const dialogRef = this.dialog.open(EditUserModalComponent, {
        minWidth: '50vw',
        minHeight:"50vh",
        data: user,
      });
  
      dialogRef.afterClosed().subscribe(result => {
        if(result) {
          this.userService.updateUser(result).subscribe(async result => {
            this.snackBar.open('Success', 'Dismiss', this.snackbarOptions);
          },
          err => {
            this.snackBar.open('An error occurred updating User', 'Dismiss', this.snackbarOptions);
            });
        }
      });
    }
    async sendResetPasswordLink(row: IMyUser) {
      await this.authService.forgotPassword(row.email).subscribe(
        data => {
          this.snackBar.open('Success', 'Dismiss', this.snackbarOptions);
        },
        err => {
          this.snackBar.open('Error', 'Dismiss', this.snackbarOptions);

        }
      );
    }
    getCompanyDetails(row: IMyUser) {
      if(this.companies.length < 1) {
        return row.companyCode;
      }
      if(row.companyCode === null || row.companyCode.length < 1)
      {
        return "";
      }
      const index = this.companies.findIndex(t=> t.id.toLowerCase().trim() === row.companyCode.toLocaleLowerCase().trim());
      if(index < 0) {
        return row.companyCode;
      }
      const myCompany = this.companies[index];
      return `${myCompany.id} - ${myCompany.name}`;
    }
    public inviteUserModal(): void {
      const dialogRef = this.dialog.open(InviteUserModalComponent, {
        width: '50vw',
        height:"50vh",
        data: {email: 'email', firstName: 'first', lastName:'last'},
      });
  
      dialogRef.afterClosed().subscribe(result => {
        if(result){
          this.authService.register(result).subscribe(result =>{

          }),
        err => {
          this.snackBar.open('An error occurred creating a new user', 'Dismiss', this.snackbarOptions);
          }
        }
      });
    }
    applyFilter(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
      this.userDataSource.filter = filterValue.trim().toLowerCase();
  
      if (this.userDataSource.paginator) {
        this.userDataSource.paginator.firstPage();
      }
    }
ngOnInit(): void {
  
}

}
