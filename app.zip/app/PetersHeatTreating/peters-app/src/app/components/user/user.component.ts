import { Component, OnInit, ViewChild } from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIcon } from '@angular/material/icon';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { forkJoin } from 'rxjs';
import { IAccountRequest } from '../../domain/IAccountRequest';
import { IMyUser } from '../../domain/IMyUser';
import { AuthService } from '../../service/auth.service';
import { CompanyService } from '../../service/company.service';
import { UserService } from '../../service/userService';
import { ConfirmModalComponent } from '../shared/confirm-modal/confirm-modal.component';
import { AccountViewModel } from './accountViewModel';
import { EditUserModalComponent } from './modal/edit-user-modal/edit-user-modal.component';
import { InviteUserModalComponent } from './modal/invite-user-modal/invite-user-modal.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  // userColumns: string[] = ['email', 'firstName', 'lastName', 'companyCode', 'lockoutEnabled', 'edit'];
  // requestColumns: string[] = ['email', 'firstName', 'lastName', 'companyName', 'companyCode',  'approve', 'deny'];
  snackbarOptions: {
    duration: 5000
  };

  isLoading = false;
  requestsLoading = false;
  users: IMyUser[] = [];
  requests: IAccountRequest[] = [];
  companies: any[] =[];
  accountViewModels: Array<any> = [];

  
  // @ViewChild(MatPaginator) userPaginator: MatPaginator;
  // @ViewChild(MatSort) userSort: MatSort;


  // requestDataSource = new MatTableDataSource<any>(this.requests);

  // userDataSource = new MatTableDataSource<IMyUser>(this.users);
  

      animal: string;
      name: string;
    
      constructor(public dialog: MatDialog,
        private snackBar: MatSnackBar, 
        private authService: AuthService,
        private userService: UserService,
        private companyService: CompanyService
        ) {}

      ngAfterViewInit() {
          
      }
          
      public inviteUserModal(): void {
        const dialogRef = this.dialog.open(InviteUserModalComponent, {
          width: '50vw',
          height:"50vh",
          data: {email: 'email', firstName: 'first', lastName:'last'},
        });
    
        dialogRef.afterClosed().subscribe(result => {
          if(result){
            this.authService.register(result).subscribe(result =>{

            }),
          err => {
            this.snackBar.open('An error occurred creating a new user', 'Dismiss', this.snackbarOptions);
            }
          }
        });
      }
  ngOnInit(): void {
    this.loadData();
  }

  loadData() {
    this.isLoading = true;
    this.users = [];
    this.companies = [];
    this.requests = [];
    forkJoin([
      this.companyService.getCompanies(),
      this.userService.getUsers()]
    ).subscribe(([companies, users]) => {
      companies.forEach(company => {
        this.companies.push(company);
      });
      users.forEach(user => {
        this.users.push(user);
        let temp = new AccountViewModel();
        temp.buildFromUser(user,this.companies);
        this.accountViewModels.push(temp);
        });
          this.isLoading = false; 
      
    },
    (err) =>{
      this.snackBar.open('Error', 'Dismiss');
    })
      
  }
}
