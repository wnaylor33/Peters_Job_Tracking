export const BASE_URL = 'api';
//export const BASE_URL = 'https://localhost:7247/api';
export const TOKEN_KEY = 'auth-token';
export const USER_KEY = 'auth-user';
export const PASSWORD_REGEX = new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$');
export const CONTACT_PHONE = '814-333-1782';
export const CONTACT_EMAIL = 'jobtracking@petersheattreat.com';



export enum Roles {
    Admin = 'Admin',
    User = 'User',
}