export interface IAccountRequest {
    id: number;
    email: string;
    companyName: string;
    firstName: string;
    lastName: string;
    approved: boolean | null;
    denied: boolean | null;
}