export interface IContactInfo {
    emailFrequency: number;
}