export interface IMyUser {
    id: string;
    email: string;
    companyCode: string;
    firstName: string;
    lastName: string;
    lockoutEnabled: boolean | null;
    isAdmin: boolean | null;
    lastLogin?: Date;
    companyName?: string;
    isVerified?: boolean
    emailFrequency?: number;
}