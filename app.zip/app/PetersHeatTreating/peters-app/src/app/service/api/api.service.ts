import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BASE_URL } from '../../constants';
const AUTH_API = 'https://localhost:7270';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class ApiService {
  constructor(private http: HttpClient) { }
  ping(): Observable<any[]> {
    return this.http.get<any>(BASE_URL + '/Ping/Ping1', httpOptions);
  }
  ping2(): Observable<any[]> {
    return this.http.get<any>(BASE_URL + '/Ping/Ping2', httpOptions);
  }
  ping3(): Observable<any[]> {
    return this.http.get<any>(BASE_URL + '/Ping/Ping3', httpOptions);
  }
}