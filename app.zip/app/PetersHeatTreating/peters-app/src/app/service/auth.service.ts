import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import {BASE_URL} from '../constants';
const AUTH_API = BASE_URL;
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private http: HttpClient) { }
  login(credentials: any): Observable<any> {
    return this.http.post(AUTH_API + '/authentication/login', {
      username: credentials.username,
      password: credentials.password
    }, httpOptions);
  }
  register(user: any): Observable<any> {
    return this.http.post(AUTH_API + '/authentication/register', user , httpOptions);
  }
  forgotPassword(username: string): Observable<any> {
    return this.http.post(AUTH_API + '/authentication/forgotpassword', {username} , httpOptions);
  }
  resetPassword(model: any): Observable<any> {
    return this.http.post(AUTH_API + '/authentication/resetPassword', {
      Username: model.username,
      Password: model.password,
      ConfirmPassword: model.password,
      Token: model.token
    }, httpOptions);
  }
}