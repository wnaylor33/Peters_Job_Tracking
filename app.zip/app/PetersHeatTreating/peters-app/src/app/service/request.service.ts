import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
  })
export class RequestService
{   
    public error: ErrorCode | null = null;
    constructor(){

    }
    public ProcessError(response: any) {
        this.error = null;
        if(response.status === 200) {
            return null;
        }
        if(response.status === 401) {
            this.error = ErrorCode.Unauthorized;
            return ErrorCode.Unauthorized;
        }
        switch (response.error) {
            case ErrorCode.InvalidToken:
                this.error = ErrorCode.InvalidToken;
                break;
        
            default:
                this.error = ErrorCode.Unknown;
                break;
        }
        return this.error;
    }
}

export enum ErrorCode {
    InvalidToken = 'InvalidToken',
    Unauthorized = "Unauthorized",
    Unknown = 'Unknown'
}