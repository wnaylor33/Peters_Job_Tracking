import { Injectable } from '@angular/core';
import { TOKEN_KEY, USER_KEY } from '../constants';
import { IMyUser } from '../domain/IMyUser';
import { JwtHelperService } from "@auth0/angular-jwt";

@Injectable({
  providedIn: 'root'
})
export class TokenService {
  constructor() { }
  logOut(): void {
    window.sessionStorage.removeItem(TOKEN_KEY);
  }
  public saveToken(token: string): void {
    window.sessionStorage.removeItem(TOKEN_KEY);
    window.sessionStorage.setItem(TOKEN_KEY, token);
  }
  public getToken() {
    return sessionStorage.getItem(TOKEN_KEY);
  }
  public saveUser(user:IMyUser): void {
    window.sessionStorage.removeItem(USER_KEY);
    window.sessionStorage.setItem(USER_KEY, JSON.stringify(user));
  }
  public getUser(): IMyUser | null {
    const item = sessionStorage.getItem(USER_KEY);
    return item ? JSON.parse(item) as IMyUser : null;
  }
  public getDecodedToken() {
    const helper = new JwtHelperService();
    const token = this.getToken();
    return token ? helper.decodeToken(token) : null;

  }
  public isTokenExpired(){
    const helper = new JwtHelperService();
    return helper.isTokenExpired(this.getToken());
  }
  public isAdmin() {
    try {
    return this.hasRole('ADMIN');
    } catch(err) {
      return false;
    }
  }
  public isRegistered(): boolean {
    return (this.getDecodedToken().IsRegistered[1]) === 'true';
  }
  public hasRole(targetRole: string) {
    const roles:string[] =this.getDecodedToken()['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
    return roles.findIndex((t) => t.toLowerCase().trim() === targetRole.toLowerCase().trim()) >= 0;
  }
  public isLoggedIn() {
    if(sessionStorage.getItem(TOKEN_KEY)) {
      try {
      if(this.isTokenExpired()){
        return false;
      }  
      return true;
      }
      catch(e){}
    }
    return false;
  }
}