import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import {BASE_URL} from '../constants';
import { IMyUser } from '../domain/IMyUser';
import { IAccountRequest } from '../domain/IAccountRequest';
import { IContactInfo } from '../domain/IContactInfo';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http: HttpClient) { }
  sendWelcomeEmail(user: any): Observable<any> {
    return this.http.post(BASE_URL + '/user/welcome', user, httpOptions);

  }
  deleteUser(user: any):Observable<any> {
    return this.http.delete<IMyUser[]>(BASE_URL + '/user/delete/' +  user.email, httpOptions);

  }
  adminSetPassword(passwordModel: any):Observable<any> {
    return this.http.post<IMyUser>(BASE_URL + '/user/admin/setPassword', passwordModel, httpOptions);
  }
  getUsers(): Observable<IMyUser[]> {
    return this.http.get<IMyUser[]>(BASE_URL + '/user', httpOptions);
  }
  getContactInfo(email:string): Observable<IContactInfo>  {
    return this.http.get<any>(BASE_URL + `/vulcan/getContactInfo?email=${email}`, httpOptions);
  }
  getCurrentUserAccount(): Observable<IMyUser> {
    return this.http.get<IMyUser>(BASE_URL + '/user/currentUser', httpOptions);
  }
  getAccountRequests(): Observable<IAccountRequest[]> {
    return this.http.get<IAccountRequest[]>(BASE_URL + '/user/requests', httpOptions);
  }
  updateUser(userModel): Observable<any> {
    return this.http.put(BASE_URL + '/user', userModel, httpOptions);
  }
  userUpdateUser(userModel): Observable<any> {
    return this.http.put(BASE_URL + '/user/myAccount', userModel, httpOptions);
  }
  createRequest(requestModel): Observable<any> {
    return this.http.post(BASE_URL + '/user/requestInvite', requestModel, httpOptions);
  }
  approveRequest(requestModel): Observable<IMyUser> {
    return this.http.post<IMyUser>(BASE_URL + '/user/approveRequest', requestModel, httpOptions);
  }
  denyRequest(requestModel): Observable<any> {
    return this.http.post(BASE_URL + '/user/denyRequest', requestModel, httpOptions);
  }

}