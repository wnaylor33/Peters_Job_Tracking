use petersheattreating;

-- create table AccountChange
-- (
-- Id int(11) NOT NULL AUTO_INCREMENT,
-- UserId varchar(125) not null,
-- FieldName varchar(75) not null,
-- NewValue varchar(250) null,
-- OldValue varchar (250) not null,
-- Created datetime default NOW(),
-- primary key(id)
-- );

alter table AccountChange
add FirstName varchar(50) null,
add LastName varchar(50) null,
add Email varchar(50) null,
add CompanyCode varchar(25),
add LogType int not null,
add Message varchar(250) null,
add RequestId int null;

update AccountChange set LogType = 1;

ALTER TABLE AccountChange CHANGE UserId UserId varchar(125) NULL;

ALTER TABLE AccountChange CHANGE FieldName FieldName varchar(75) NULL;

ALTER TABLE AccountChange CHANGE OldValue OldValue varchar(250) NULL;



select uuid();