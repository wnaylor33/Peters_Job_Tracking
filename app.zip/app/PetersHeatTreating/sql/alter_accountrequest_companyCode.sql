alter table petersheattreating.accountrequest
add CompanyCode varchar(10) null