use petersheattreating;
alter table aspnetusers
add CompanyName varchar(250) null,
 add Created datetime default now(),
 add LastLogin datetime null,
add IsVerified bool default false not null;

update aspnetusers set IsVerified = true;