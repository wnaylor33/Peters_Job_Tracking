SELECT * FROM petersheattreating.aspnetusers;

alter table petersheattreating.aspnetusers
add City varchar(255) null,
add State varchar(50) null