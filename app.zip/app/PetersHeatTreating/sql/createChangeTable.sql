use petersheattreating;

create table AccountChange
(
Id int(11) NOT NULL AUTO_INCREMENT,
UserId varchar(125) not null,
FieldName varchar(75) not null,
NewValue varchar(250) null,
OldValue varchar (250) not null,
Created datetime default NOW(),
primary key(id)
);
