use petersheattreating;
create table AccountRequest(
Id int(11) NOT NULL AUTO_INCREMENT,
FirstName varchar(75) not null,
LastName varchar(75) not null,
Email varchar(75) not null,
CompanyName varchar(25) not null,
Approved bit null,
Denied bit null,

Created datetime default NOW(),
PRIMARY KEY (Id)
);


