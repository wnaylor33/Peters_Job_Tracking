insert into AspNetRoles(
    Id,
    Name,
    ConcurrencyStamp,
    NormalizedName
)
VALUES
(uuid(), 'User', uuid(), 'User'),
(uuid(), 'Admin', uuid(), 'Admin')