use petersheattreating;
insert into AspNetUsers
(
id,
ConcurrencyStamp,
Email,
EmailConfirmed,
FirstName,
LastName,
SecurityStamp,
TwoFactorEnabled,
UserName,
NormalizedEmail,
NormalizedUserName,
PhoneNumberConfirmed,
LockoutEnabled ,
AccessFailedCount
)
VALUES
(
uuid(),
uuid(),
"wnaylor33@gmail.com",
1,
'William',
'Naylor',
uuid(),
0,
"wnaylor33@gmail.com",
"wnaylor33@gmail.com",
"wnaylor33@gmail.com",
0,
0,
0
);


insert into AspNetUserRoles
(
UserId,
RoleId)
VALUES
(
(select Id from AspNetUsers where Email like '%wnaylor33%' limit 1),
(select Id from AspNetRoles where Name like '%User%'limit 1)
),
(
(select Id from AspNetUsers where Email like '%wnaylor33%' limit 1),
(select Id from AspNetRoles where Name like '%Admin%'limit 1)
)
