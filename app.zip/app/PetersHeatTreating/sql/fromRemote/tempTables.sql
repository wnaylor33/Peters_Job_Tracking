use petersheattreating;
create table Jobs(
Id int(11) NOT NULL AUTO_INCREMENT,
CustomerPo varchar(30) not null,
MaterialCode varchar(30) not null,
Weight varchar(25) not null,
Status varchar(25) not null,
StatusTime datetime default NOW(),
JobReceived datetime default NOW(),
Pieces varchar(25) not null,
Shipping varchar(75) not null,
PRIMARY KEY (Id)
);
create table Company(
Id int(11) NOT NULL AUTO_INCREMENT,
Name varchar(75) not null,
IsInactive bit default 0,
PRIMARY KEY (Id)
);





