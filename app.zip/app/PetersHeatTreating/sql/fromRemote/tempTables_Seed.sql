use petersheattreating;


insert into Jobs(
    CustomerPo,
    MaterialCode,
    Weight,
    Status,
    StatusTime,
    JobReceived,
    Pieces,
    Shipping
)
VALUES
("12345","R-6","2","SHIPPING",NOW(),(now() + INTERVAL 15 MINUTE), "5", "PICKUP@PM"),
("12346","0-1","2","TEMPERING",NOW(),(now() + INTERVAL 25 MINUTE), "1", "PICKUP@PM"),
("12335","L-2","2","RECEIVING",NOW(),(now() + INTERVAL 56 MINUTE), "3", "PICKUP@PM"),
("13445","L-3","2","SHIPPING",NOW(),(now() + INTERVAL 54 MINUTE), "5", "PICKUP@PM"),
("12111","O-6","2","TEMPERING",NOW(),(now() + INTERVAL 555 MINUTE), "7", "PICKUP@PM"),
("12343","T-3","2","RECEIVING",NOW(),(now() + INTERVAL 5555 MINUTE), "85", "PICKUP@PM"),
("12332","L-2","2","TEMPERING",NOW(),(now() + INTERVAL 534 MINUTE), "5", "PICKUP@PM"),
("12475","L-3","2","RECEIVING",NOW(),(now() + INTERVAL 524 MINUTE), "5", "PICKUP@PM"),
("12695","L-5","2","SHIPPING",NOW(),(now() + INTERVAL 523 MINUTE), "53", "PICKUP@PM"),
("10915","K-6","2","RECEIVING",NOW(),(now() + INTERVAL 5 MINUTE), "51", "PICKUP@PM"),
("12295","L-6","2","TEMPERING",NOW(),(now() + INTERVAL 9 MINUTE), "5", "PICKUP@PM"),
("10925","M-6","2","RECEIVING",NOW(),(now() + INTERVAL 53 MINUTE), "3", "PICKUP@PM"),
("92825","N-6","2","RECEIVING",NOW(),(now() + INTERVAL 52 MINUTE), "5", "PICKUP@PM"),
("19835","L-6","2","TEMPERING",NOW(),(now() + INTERVAL 25 MINUTE), "45", "PICKUP@PM"),
("93845","L-6","2","RECEIVING",NOW(),(now() + INTERVAL 5 MINUTE), "32", "PICKUP@PM"),
("98345","L-1","2","RECEIVING",NOW(),(now() + INTERVAL 25 MINUTE), "35", "PICKUP@PM"),
("74645","L-2","2","SHIPPING",NOW(),(now() + INTERVAL 95 MINUTE), "53", "PICKUP@PM"),
("93845","L-4","2","RECEIVING",NOW(),(now() + INTERVAL 85 MINUTE), "51", "PICKUP@PM"),
("90345","R-3","2","RECEIVING",NOW(),(now() + INTERVAL 95 MINUTE), "53", "PICKUP@PM"),
("88845","I-6","2","TEMPERING",NOW(),(now() + INTERVAL 35 MINUTE), "54", "PICKUP@PM"),
("38345","P-1","2","TEMPERING",NOW(),(now() + INTERVAL 15 MINUTE), "55", "PICKUP@PM"),
("12932","L-2","2","TEMPERING",NOW(),(now() + INTERVAL 5 MINUTE), "55", "PICKUP@PM"),
("39472","L-3","2","TEMPERING",NOW(),(now() + INTERVAL 95 MINUTE), "57", "PICKUP@PM"),
("28472","Y-5","2","TEMPERING",NOW(),(now() + INTERVAL 6 MINUTE), "53", "PICKUP@PM"),
("49281","O-6","2","RECEIVING",NOW(),(now() + INTERVAL 7 MINUTE), "52", "PICKUP@PM"),
("39281","R-6","2","RECEIVING",NOW(),(now() + INTERVAL 77 MINUTE), "53", "PICKUP@PM"),
("13872","L-3","2","RECEIVING",NOW(),(now() + INTERVAL 76 MINUTE), "55", "PICKUP@PM"),
("92847","R-1","2","RECEIVING",NOW(),(now() + INTERVAL 53 MINUTE), "56", "PICKUP@PM"),
("93827","L-0","2","TEMPERING",NOW(),(now() + INTERVAL 51 MINUTE), "57", "PICKUP@PM"),
("29384","L-9","2","RECEIVING",NOW(),(now() + INTERVAL 555 MINUTE), "59", "PICKUP@PM"),
("12983","O-6","2","TEMPERING",NOW(),(now() + INTERVAL 532 MINUTE), "58", "PICKUP@PM"),
("29182","O-6","2","TEMPERING",NOW(),(now() + INTERVAL 521 MINUTE), "54", "PICKUP@PM"),
("13215","L-6","2","RECEIVING",NOW(),(now() + INTERVAL 532 MINUTE), "55", "PICKUP@PM"),
("13925","K-6","2","RECEIVING",NOW(),(now() + INTERVAL 55 MINUTE), "53", "PICKUP@PM"),
("93825","R-9","2","RECEIVING",NOW(),(now() + INTERVAL 5 MINUTE), "52", "PICKUP@PM"),
("39285","T-6","2","SHIPPING",NOW(),(now() + INTERVAL 5 MINUTE), "53", "PICKUP@PM"),
("94875","R-5","2","TEMPERING",NOW(),(now() + INTERVAL 53 MINUTE), "65", "PICKUP@PM"),
("34855","J-3","2","SHIPPING",NOW(),(now() + INTERVAL 5 MINUTE), "5", "PICKUP@PM"),
("32915","R-6","2","TEMPERING",NOW(),(now() + INTERVAL 156 MINUTE), "15", "PICKUP@PM");


insert into Company(
    Name,
    IsInactive
)
VALUES
('Company 1', 0),
    ('Company 2', 0),
    ('Company 3', 0),
    ('Company 4', 0),
    ('Company 5', 0),
    ('Company 6', 0),
    ('Company 7', 0),
    ('Company 8', 0),
    ('Company 9', 0),
    ('Company 10', 0),
    ('Company 11', 0);



